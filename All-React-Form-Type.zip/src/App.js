import './App.css';
import ControlledFormWay from './componanat/ControlledFormWay';
import DefaultValuesinForm from './componanat/DefaultValuesinForm';
import FormValidation from './componanat/FormValidation';
import HandlingMultipleInputs from './componanat/HandlingMultipleInputs';
import ManagingDatawithoutSubmit from './componanat/ManagingDatawithoutSubmit';
import UncontrolledFormWay from './componanat/UncontrolledFormWay';

function App() {
  return (
    <div className="App">
      <h1>Forms</h1>
      <UncontrolledFormWay/>
      <ControlledFormWay/>
      <ManagingDatawithoutSubmit/>
      <HandlingMultipleInputs/>
      <FormValidation/>
      <DefaultValuesinForm/>
    </div>
  );
}

export default App;
