import React from 'react'
import { useState } from 'react'

export default function HandlingMultipleInputs() {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        language: '',
        likecoding: false
    });


    function handleSubmit(e) {
        const { name, type, value, checked } = e.target;
        const inputValue = type === "checkbox" ? checked : value;
        setFormData(prevState => ({ ...prevState, [name]: inputValue }));
    }

    
    return (
        <div>
            <h3>Handling Multiple Inputs</h3>
            <input type='text' name='firstName' value={formData.firstName} onChange={handleSubmit} />
            
            <br />
            <input type='text' name='lastName' value={formData.lastName} onChange={handleSubmit} />
           
            <br />
            <select name='language' onChange={handleSubmit}>
                <option>HTML</option>
                <option>Javascript</option>
                <option>CSS</option>
                <option>React</option>
            </select>
            <br />
            <label>
                <input type='checkbox' name='likecoding' checked={formData.likecoding} onChange={handleSubmit} />
                Do You Like Coding
            </label>
            <br />
            <p>Your Fullname is a {formData.firstName} {formData.lastName}</p>
            <p>Your lang {formData.language} </p>
            <p>do you like codeing {formData.likecoding ? 'Yes' : 'No'} </p>
        </div>
    )
}
