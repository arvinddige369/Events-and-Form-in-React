import React from 'react'

export default function UncontrolledFormWay() {
    function handleSubmitNew(event) {
event.preventDefault();
alert('a Name was submited'+ event.target.inputName.value);
    }
    return (
        <div>
        <h3>Uncontrolled Way Form</h3>
            <form onSubmit={handleSubmitNew}>
                <label>Name:</label>
                <input type='text' name="inputName" />
                <button type='submit'>Submit</button>
            </form>
        </div>
    )
}
