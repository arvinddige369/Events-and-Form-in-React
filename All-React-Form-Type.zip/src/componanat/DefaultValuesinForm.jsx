import React from 'react';
import { useState } from 'react';

export default function DefaultValuesinForm() {

    const Default_value_firstName = 'Jone';
    const Default_value_lastName = 'Deo';
    const Default_value_language = 'Javascript';


    const [formData, setFormData] = useState({
        firstName: Default_value_firstName,
        lastName: Default_value_lastName,
        language: Default_value_language
    });

  return (
    <div>
    <h4>Default Values in Form</h4>
    <input type='text' name='firstName' value={formData.firstName}  />
           
            <br />
            <input type='text' name='lastName' value={formData.lastName} />
            
            <br />
            <select name='language'value={formData.language}>
                <option>Select</option>
                <option>HTML</option>
                <option>Javascript</option>
                <option>CSS</option>
                <option>React</option>
            </select>
          
            <br />
            <button type='submit'>Submit</button>
            <br />
            </div>
  )
}
