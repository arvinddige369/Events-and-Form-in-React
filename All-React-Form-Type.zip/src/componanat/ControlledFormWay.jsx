import React, { useState }  from 'react';

export default function ControlledFormWay() {
    const [name, setName] = useState('');
    function handleSubmit(event){
        event.preventDefault();
        alert('A Form was Submited ' + name)
    }
  return (
    <div>
    <h3>Controlled Way Form</h3>
    <form onSubmit={handleSubmit}>
    <label>Name:</label>
    <input type='text' name='nameInput' value={name} onChange={e => setName(e.target.value)} />
    <button type='submit'>Submit</button>
    </form>
    </div>
  )
}
