import React from 'react'
import { useState } from 'react'

export default function ManagingDatawithoutSubmit() {
    const [name, setName] = useState('');
  return (
    <div>
    <h3>Managing Data without Submit</h3>
    <input type='text' name='inputName' value={name} onChange={e => setName(e.target.value)}/>
    <p> Your name is {name}</p>
    </div>
  )
}
