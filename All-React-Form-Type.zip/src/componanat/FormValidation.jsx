import React from 'react'
import { useState } from 'react'

export default function FormValidation() {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        language: '',
        likecoding: false
    });

    const [errors, setErrors] = useState({
        firstName: '',
        lastName: '',
        language: ''
    });

    function handleSubmit(e) {
        const { name, value, } = e.target;
        setErrors(prevErrors => ({ ...prevErrors, [name]: '' }));
        setFormData(prevState => ({ ...prevState, [name]: value }));
    }

    const handelChange = () => {
        let valid = true;
        const temError = {
            firstName: formData.firstName ? '' : 'first name req',
            lastName: formData.lastName ? '' : 'Last name req',
            language: formData.language ? '' : 'language req'
        }

        for (const error in temError) {
            if (temError[error]) valid = false
        }

        setErrors(temError)
        if (valid) {
            alert('form was submited')
        }
    }
    return (
        <div>
            <h3>Form Validation</h3>
            <input type='text' name='firstName' value={formData.firstName} onChange={handleSubmit} />
            {errors.firstName && <p className='error'>{errors.firstName}</p>}
            <br />
            <input type='text' name='lastName' value={formData.lastName} onChange={handleSubmit} />
            {errors.lastName && <p className='error'>{errors.lastName}</p>}
            <br />
            <select name='language' onChange={handleSubmit}>
                <option>Select</option>
                <option>HTML</option>
                <option>Javascript</option>
                <option>CSS</option>
                <option>React</option>
            </select>
            {errors.language && <p className='error'>{errors.language}</p>}
            <br />
            <button type='submit' onClick={handelChange}>Submit</button>
            <br />

        </div>
    )
}